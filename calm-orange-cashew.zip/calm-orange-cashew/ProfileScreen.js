import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import UpdateProfile from './UpdateProfileScreen';
export default function HomeScreen() {
  const navigation = useNavigation();

  return (
    <View style={styles.container}>
      {/* Yellow navbar */}
      <View style={styles.navbar}>
        <TouchableOpacity onPress={() => navigation.openDrawer()}>
          <Ionicons name="menu" size={30} color="darkblue" />
        </TouchableOpacity>
        <Text style={styles.navbarText}>Trade Fair Gambia</Text>
        <TouchableOpacity onPress={() => console.log('Logout clicked')}>
          <Ionicons name="log-out" size={30} color="darkblue" />
        </TouchableOpacity>
      </View>

      <View style={styles.containers}>
        <Image 
          source={{ uri: 'https://i.pravatar.cc/300' }}
          style={styles.avatar}
        />
        <Text style={styles.name}>John Doe</Text>
        <Text style={styles.email}>6608033</Text>

        {/* ✅ Corrected Navigation for Each Button */}
        <TouchableOpacity 
          style={styles.button} 
          onPress={() => navigation.navigate('UpdateProfile')}
        >
          <Text style={styles.buttonText}>UPDATE MY PROFILE</Text>
          <Ionicons name="chevron-forward-outline" size={20} color="white" />
        </TouchableOpacity>

        <TouchableOpacity 
          style={styles.button} 
          onPress={() => navigation.navigate('MyStalls')}
        >
          <Text style={styles.buttonText}>MY STALLS</Text>
          <Ionicons name="chevron-forward-outline" size={20} color="white" />
        </TouchableOpacity>

        <TouchableOpacity 
          style={styles.button} 
          onPress={() => navigation.navigate('MyTickets')}
        >
          <Text style={styles.buttonText}>MY TICKETS</Text>
          <Ionicons name="chevron-forward-outline" size={20} color="white" />
        </TouchableOpacity>

        <TouchableOpacity 
          style={styles.button} 
          onPress={() => navigation.navigate('Languages')}
        >
          <Text style={styles.buttonText}>LANGUAGES</Text>
          <Ionicons name="chevron-forward-outline" size={20} color="white" />
        </TouchableOpacity>

        <TouchableOpacity 
          style={styles.button} 
          onPress={() => navigation.navigate('PrivacySettings')}
        >
          <Text style={styles.buttonText}>PRIVACY & SECURITY SETTINGS</Text>
          <Ionicons name="chevron-forward-outline" size={20} color="white" />
        </TouchableOpacity>

        <TouchableOpacity style={styles.buttons} onPress={() => console.log('Delete account pressed')}>
          <Text style={styles.buttonsText}>Delete my account</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'darkblue',
    top: 10,
  },
  containers:{
    flex: 1,
    alignItems: 'center',
    padding: 20,
    top: 50
  },
  avatar: {
    width: 120,
    height: 120,
    borderRadius: 60,
    top: 30,
  },
  name: {
    fontSize: 30,
    fontWeight: 'bold',
    color: 'white',
    top: 35
  },
  email: {
    fontSize: 18,
    color: 'white',
    marginBottom: 19,
    top: 40,
  },
  button: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#0056b3',
    paddingVertical: 12,
    paddingHorizontal: 15,
    borderRadius: 10,
    width: 300,
    top: 40,
    marginBottom: 10,
  },
  buttons: {
    height: 50,
    width: 200,
    backgroundColor: 'red',
    top: 60,
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
  },
  buttonsText: {
    color: '#fff',
    fontSize: 16,
    paddingVertical: 10,
    paddingHorizontal: 30,
  },
  navbar: {
    width: '100%',
    height: 60,
    backgroundColor: '#FFD700',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    position: 'absolute',
    top: 10,
    zIndex: 10,
  },
  navbarText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'darkblue',
  },
});

