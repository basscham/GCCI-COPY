import React, { useEffect, useState } from 'react';
import { View, ActivityIndicator, StyleSheet } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { Ionicons } from '@expo/vector-icons';
import { StatusBar } from 'expo-status-bar';
import * as SplashScreen from 'expo-splash-screen';

// Import Screens
import HomeScreen from './HomeScreen';
import ExhibitorsScreen from './ExhibitorsScreen';
import ProfileScreen from './ProfileScreen';
import UpdateProfileScreen from './UpdateProfileScreen';
import MyStallsScreen from './MyStallsScreen';
import MyTicketsScreen from './MyTicketsScreen';
import LanguagesScreen from './LanguagesScreen';
import PrivacySettingsScreen from './PrivacySettingsScreen';

const Drawer = createDrawerNavigator();
const Tab = createBottomTabNavigator();
const Stack = createNativeStackNavigator();

// Prevent Splash Screen from auto-hiding
SplashScreen.preventAutoHideAsync();

// ✅ Profile Stack: Handles profile and related screens
function ProfileStackScreen() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="ProfileHome" component={ProfileScreen} options={{ title: 'Profile' }} />
      <Stack.Screen name="UpdateProfile" component={UpdateProfileScreen} />
      <Stack.Screen name="MyStalls" component={MyStallsScreen} />
      <Stack.Screen name="MyTickets" component={MyTicketsScreen} />
      <Stack.Screen name="Languages" component={LanguagesScreen} />
      <Stack.Screen name="PrivacySettings" component={PrivacySettingsScreen} />
    </Stack.Navigator>
  );
}

// ✅ Bottom Tab Navigator
function BottomTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ color, size }) => {
          let iconName;
          if (route.name === 'Home') iconName = 'home';
          else if (route.name === 'Exhibitors') iconName = 'people';
          else if (route.name === 'Profile') iconName = 'person';

          return <Ionicons name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: 'darkblue',
        tabBarInactiveTintColor: 'gray',
        tabBarStyle: { backgroundColor: '#FFD700', height: 60 },
        headerShown: false,
      })}
    >
      <Tab.Screen name="Home" component={HomeScreen} />
      <Tab.Screen name="Exhibitors" component={ExhibitorsScreen} />
      <Tab.Screen name="Profile" component={ProfileStackScreen} />
    </Tab.Navigator>
  );
}

// ✅ App Component with Splash Screen
export default function App() {
  const [appReady, setAppReady] = useState(false);

  useEffect(() => {
    async function loadApp() {
      // Simulate a loading process (e.g., fetching data, assets)
      setTimeout(async () => {
        setAppReady(true);
        await SplashScreen.hideAsync(); // Hide splash screen after loading
      }, 2000);
    }
    loadApp();
  }, []);

  if (!appReady) {
    return (
      <View style={styles.splashContainer}>
        <ActivityIndicator size="large" color="#FFD700" />
      </View>
    );
  }

  return (
    <NavigationContainer>
      {/* Global StatusBar */}
      <StatusBar style="light" backgroundColor="darkblue" />

      <Drawer.Navigator
        initialRouteName="Home"
        screenOptions={{
          headerShown: false,
          backgroundColor: 'darkblue',
        }}
      >
        <Drawer.Screen name="Home" component={BottomTabs} />
        <Drawer.Screen name="Exhibitors" component={ExhibitorsScreen} />
        <Drawer.Screen name="Settings" component={ProfileStackScreen} />
      </Drawer.Navigator>
    </NavigationContainer>
  );
}

// Styles
const styles = StyleSheet.create({
  splashContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FFD700',
  },
});
