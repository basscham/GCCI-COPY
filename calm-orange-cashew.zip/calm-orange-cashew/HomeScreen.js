import {
  View,
  Text,
  Image,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons'; // Import Ionicons for menu and logout icons

export default function HomeScreen() {
   const navigation = useNavigation();

  return (
    <View style={styles.container}>
      {/* Yellow navbar */}
      <View style={styles.navbar}>
        <TouchableOpacity onPress={() => navigation.openDrawer()}>
          <Ionicons name="menu" size={30} color="darkblue" />
        </TouchableOpacity>
        <Text style={styles.navbarText}>Trade Fair Gambia</Text>
        <TouchableOpacity onPress={() => console.log('Logout clicked')}>
          <Ionicons name="log-out" size={30} color="darkblue" />
        </TouchableOpacity>
      </View>

      <Text style={styles.hero}>Hi,USER</Text>
      <Text style={styles.hero2}>Welcome to TFGI 18th Edition</Text>
      
      <View style={styles.containers}>
        {/* Buy Stall Button */}
        <TouchableOpacity onPress={() => navigation.navigate('Profile', { screen: 'MyStalls' })}>
          <View style={styles.card}>
            <Ionicons
              name="shopping-cart"
              size={30}
              color="darkblue"
            />
            <Text style={styles.cardText}>Buy Stall</Text>
          </View>
        </TouchableOpacity>
        
        {/* Buy Ticket Button */}
        <TouchableOpacity onPress={() => navigation.navigate('Profile', { screen: 'MyTickets' })}>
          <View style={styles.card}>
            <Ionicons
              name="ticket"
              size={30}
              color="darkblue"
            />
            <Text style={styles.cardText}>Buy Ticket</Text>
          </View>
        </TouchableOpacity>
      </View>

      <Text style={styles.heros}>ANNOUNCEMENTS</Text>

      <View>
        <Image 
          source={{ uri: 'https://www.qcity.gm/themes/demo/assets/images/icon.png' }}
          style={styles.image}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'darkblue',
    top: 10,
  },
  heros: {
    width: '100%',
    height: 60,
    backgroundColor: 'darkblue', // Yellow background
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    position: 'absolute',
    top: 315,
    zIndex: 10,
    color: 'white',
    fontWeight: 'bold',
    fontSize: 30,
  },
  containers: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    gap: 10,
    marginTop: 200,
    marginBottom: 190,
  },
  card: {
    width: 160,
    alignItems: 'center',
    padding: 10,
    borderRadius: 10,
    borderWidth: 1,
    backgroundColor: '#FFD700',
    height: 100,
    marginBottom: 150,
  },
  cardText: {
    marginTop: 10,
    fontSize: 20,
    fontWeight: 'bold',
    color: 'darkblue',
  },

  hero: {
    width: '100%',
    height: 60,
    backgroundColor: 'darkblue',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    position: 'absolute',
    top: 75,
    zIndex: 10,
    color: 'white',
    fontWeight: 'bold',
    fontSize: 30,
  },
  hero2: {
    width: '100%',
    height: 20,
    backgroundColor: 'darkblue',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    position: 'absolute',
    top: 120,
    zIndex: 10,
    color: 'white',
    fontWeight: 'bold',
    fontSize: 17,
  },

  navbar: {
    width: '100%',
    height: 60,
    backgroundColor: '#FFD700',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    position: 'absolute',
    top:10,
    zIndex: 10,
  },
  navbarText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'darkblue',
  },
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 20, marginTop: 1 },
  image: {
    width: 200,
    height: 100,
    marginTop: 20,
  },
});
