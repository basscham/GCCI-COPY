import React, { useState } from 'react';
import { View, Text, Button, StyleSheet, TouchableOpacity } from 'react-native';

export default function BuyTicketScreen({ navigation }) {
  const [selectedTicket, setSelectedTicket] = useState(null);

  // Function to handle selecting a ticket type
  const selectTicket = (ticket) => {
    setSelectedTicket(ticket);
  };

  // Function to handle ticket purchase
  const buyTicket = () => {
    if (selectedTicket) {
      alert(`You have purchased a ${selectedTicket} ticket!`);
      navigation.goBack(); // Go back to the previous screen
    } else {
      alert('Please select a ticket to buy!');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Buy Ticket</Text>

      <Text style={styles.subtitle}>Select your ticket:</Text>

      {/* Ticket options */}
      <View style={styles.ticketOptions}>
        <TouchableOpacity 
          style={styles.option}
          onPress={() => selectTicket('VIP')}
        >
          <Text style={styles.optionText}>VIP Ticket</Text>
        </TouchableOpacity>

        <TouchableOpacity 
          style={styles.option}
          onPress={() => selectTicket('General')}
        >
          <Text style={styles.optionText}>General Ticket</Text>
        </TouchableOpacity>

        <TouchableOpacity 
          style={styles.option}
          onPress={() => selectTicket('Student')}
        >
          <Text style={styles.optionText}>Student Ticket</Text>
        </TouchableOpacity>
      </View>

      {/* Show selected ticket */}
      {selectedTicket && (
        <Text style={styles.selectedTicket}>You selected: {selectedTicket} Ticket</Text>
      )}

      {/* Buy Ticket Button */}
      <TouchableOpacity style={styles.buyButton} onPress={buyTicket}>
        <Text style={styles.buyButtonText}>Buy Ticket</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.goBackButton} onPress={() => navigation.goBack()}>
        <Text style={styles.goBackButtonText}>Go Back</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'darkblue',
    padding: 20,
  },


  buyButton: {
    backgroundColor: '#4CAF50', // Green for Buy Ticket button
    padding: 15,
    borderRadius: 8,
    width: '50%',
    marginBottom: 15,
    alignItems: 'center',
  },
  buyButtonText: {
    fontSize: 20,
    color: '#fff',
    fontWeight: 'bold',
  },
  goBackButton: {
    backgroundColor: '#f44336', // Red for Go Back button
    padding: 15,
    borderRadius: 8,
    width: '40%',
    alignItems: 'center',
  },
  goBackButtonText: {
    fontSize: 20,
    color: '#fff',
    fontWeight: 'bold',
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    marginBottom: 20,
    color:'white'
  },
  subtitle: {
    fontSize: 20,
    marginBottom: 20,
    color:'white'
  },
  ticketOptions: {
    width: '80%',
    marginBottom: 20,
  },
  option: {
    backgroundColor: '#FFD700',
    padding: 15,
    marginVertical: 5,
    borderRadius: 8,
  },
  optionText: {
    fontSize: 18,
    textAlign: 'center',
    color: '#000',
    bold:10
  },
  selectedTicket: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 20,
    color: 'white',
  },
});
