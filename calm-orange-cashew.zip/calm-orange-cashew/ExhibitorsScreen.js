import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  FlatList,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  Keyboard
} from 'react-native';
import { Ionicons } from '@expo/vector-icons'; // Import Ionicons for menu and logout icons

const exhibitorsData = [
  { id: '1', name: 'Tech Solutions', category: 'Tech' },
  { id: '2', name: 'Green Energy Ltd', category: 'Energy' },
  { id: '3', name: 'Fashion World', category: 'Fashion' },
  { id: '4', name: 'Food Lovers', category: 'Food' },
  { id: '5', name: 'Handmade Crafts', category: 'Crafts' },
];

export default function ExhibitorScreen() {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState('All');

  // Filter exhibitors based on search query and active tab
  const filteredExhibitors = exhibitorsData.filter(exhibitor =>
    (activeTab === 'All' || exhibitor.category === activeTab) &&
    exhibitor.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      {/* Yellow navbar */}
      <View style={styles.navbar}>
        <TouchableOpacity onPress={() => console.log('Menu clicked')}>
          <Ionicons name="menu" size={30} color="darkblue" />
        </TouchableOpacity>
        <Text style={styles.navbarText}>Trade Fair Gambia</Text>
        <TouchableOpacity onPress={() => console.log('Logout clicked')}>
          <Ionicons name="log-out" size={30} color="darkblue" />
        </TouchableOpacity>
      </View>

      {/* Hero Section */}
      <View style={styles.heroSection}>
        <Text style={styles.hero}>Hi,USER</Text>
        <Text style={styles.hero2}>Welcome to TFGI 18th Edition</Text>
      </View>

      {/* Search Box */}
      <View style={styles.searchContainer}>
        <TextInput
          style={styles.searchBox}
          placeholder="Search exhibitors..."
          placeholderTextColor="gray"
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
      </View>

      {/* Tab Section */}
      <View style={styles.exhibitorTabsContainer}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.tabs}>
          {/* Tabs for categories */}
          {['All', 'Tech', 'Energy', 'Fashion', 'Food', 'Crafts'].map((category) => (
            <TouchableOpacity
              key={category}
              style={[
                styles.tabButton,
                activeTab === category && styles.activeTab
              ]}
              onPress={() => setActiveTab(category)}
            >
              <Text style={styles.tabButtonText}>{category}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>

      {/* Exhibitors List */}
      <FlatList
        data={filteredExhibitors}
        keyExtractor={item => item.id}
        renderItem={({ item }) => (
          <View style={styles.exhibitorCard}>
            <Text style={styles.exhibitorName}>{item.name}</Text>
          </View>
        )}
      />
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'darkblue',
    top: 10,
  },
  exhibitorTabsContainer: {
    paddingHorizontal: 10,
    marginTop: 50,
  },
  tabs: {
    flexDirection: 'row',
  },
  tabButton: {
    paddingVertical: 10,
    paddingHorizontal: 20,
    marginRight: 10,
    backgroundColor: '#FFD700',
    borderRadius: 5,
  },
  activeTab: {
    backgroundColor: '#FF6347', // Highlight the active tab with a different color
  },
  tabButtonText: {
    color: 'darkblue',
    fontWeight: 'bold',
    fontSize: 16,
  },
  exhibitorCard: {
    backgroundColor: '',
    padding: 15,
    borderRadius: 10,
    marginBottom: 5,
  },
  exhibitorName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
  },
  navbar: {
    width: '100%',
    height: 60,
    backgroundColor: '#FFD700',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    zIndex: 10,
    top:10,
  },
  navbarText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'darkblue',
  },
  heroSection: {
    marginTop: 80,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
  },
  hero: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 30,
  },
  hero2: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 17,
  },
  searchContainer: {
    padding: 20,
    position: 'center',
    marginRight: 50,
  },
  searchBox: {
    position: 'absolute',
    height: 50,
    width: '100%',
    borderWidth: 1,
    borderColor: '#FFD700',
    borderRadius: 15,
    paddingHorizontal: 15,
    fontSize: 16,
    marginBottom: 20,
    color: 'black',
    backgroundColor: 'white',
    left: 40,
  },
});
